# RAK811-Arduino
Arduino Library for Pi Supply LoRa Node Shield

This repository has our fork of the RAK811 Arduino Library with modifications and better documentation.

The original library can be found at https://github.com/RAKWireless/RAK811/tree/master/Arduino%20Library

# Instructions
Download this library and put it into your Arduino Libaries Folder (Usually Arduino then Libraries in your documents / home)

Then you **need** to run the Setbaudrate Example, this will configure the RAK Chip to run at 9600 Baud as on the arduino we have experienced issues at 115200 Baud.

Finally you can run one of the examples.
